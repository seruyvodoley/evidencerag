# Данные

Пять авторских корпусов CC0 в datasets/demo: две редакции инструкции «Север», две версии API «Лист», два регламента «Контур», один несогласованный архивный регламент и три документа комплекта «Полюс». Всего 10 документов. Это небольшие качественные fixtures, а не репрезентативный benchmark.

Генератор: scripts/create_demo.py. Разметка: `datasets/evaluation/cases.json`, 63 случая, из них 21 test. Есть явные факты, отсутствие информации, изменения версий/дат, внутренний конфликт, лексически похожий текст без цены и вопрос по нескольким документам. Поля включают id, split, evaluation_cluster, question, family, version, as_of, gold_answer, required, `expected_resolution`, sufficient, conflict, category, abstention_reasons. Все редакции одного семейства помещены в один split; bundle задачи также образуют один кластер.

Датированные примеры `device-date`, `api-date` и `service-date` размечены точными ожидаемыми значениями и строками источников. Прежняя версия данных задавала `sufficient=true`, но оставляла `gold_answer` и `required` пустыми; эта разметка не годилась для retrieval-recall. Исторические run-001—run-003 сохранены неизменными и отражают эту старую схему. Новая оценка не использует `sufficient` для вычисления answer quality: без генератора/semantic judge answer metrics null.

| Внешний набор | Пригодность и лицензия по первичному источнику | Статус |
|---|---|---|
| [RAGBench](https://huggingface.co/datasets/galileo-ai/ragbench/blob/main/README.md) | Карточка CC BY 4.0; атрибуция/полнота ответов. Разнородные исходные корпуса требуют проверки конкретного поднабора. Нет готовой разметки эволюции версий. | Не загружен. |
| [CRAG](https://github.com/facebookresearch/CRAG) | [Лицензия репозитория](https://github.com/facebookresearch/CRAG/blob/main/LICENSE): CC BY-NC 4.0. Временные/динамические вопросы полезны; не включать в коммерческую публичную демогалерею. | Не загружен. |
| [HotpotQA](https://hotpotqa.github.io/) | CC BY-SA 4.0 для QA и обработанной Wikipedia согласно странице авторов; полезен multi-hop и supporting facts, но не версионная применимость. | Не загружен. |
| [2WikiMultiHopQA](https://github.com/Alab-NII/2wikimultihop) | Репозиторий Apache 2.0; полезны цепочки свидетельств. Происхождение Wikipedia/Wikidata и конкретные распространяемые файлы надо учитывать отдельно. | Не загружен. |

Лицензионная проверка здесь — фиксация карточек авторов, не универсальное юридическое разрешение на все производные материалы. На VPS внешние датасеты и GPU-модели не загружались.

Для stage-006 рассмотрены два versioned candidate source из официальной документации Python 3.12 и 3.13; source pages и лицензия указаны в [протоколе корпуса/разметки](CORPUS_ANNOTATION_PROTOCOL_006.md). Они пока не импортированы и не размечены. Поэтому `experiments/research-rag-pilot-004/` продолжает использовать только этот синтетический demonstration corpus и не считается real-world evaluation.
